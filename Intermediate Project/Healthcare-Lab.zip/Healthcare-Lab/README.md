# 🏥 Data Science Lab Work – Healthcare Project

## Project 4: Diabetes Risk Analysis & Prediction

An intermediate-level Data Science project analyzing patient medical records to identify diabetes risk factors and build predictive models for early diagnosis.

---

## 📁 Structure

```
Healthcare-Lab/
│
├── data/
│   └── diabetes_patients.csv        # 60 patient medical records
│
├── notebooks/
│   └── 04_Healthcare_Diabetes_Analysis.py
│
├── outputs/                         # 10 plots (auto-generated)
│
└── README.md
```

---

## 📊 Dataset – `diabetes_patients.csv`

| Feature | Type | Description |
|---|---|---|
| `Age` | Numeric | Patient age in years |
| `Gender` | Categorical | Male / Female |
| `BMI` | Numeric | Body Mass Index |
| `BloodPressure_mmHg` | Numeric | Systolic blood pressure |
| `GlucoseLevel` | Numeric | Fasting glucose (mg/dL) |
| `HbA1c` | Numeric | Glycated hemoglobin (%) |
| `PhysicalActivity` | Ordinal | None / Low / Moderate / High |
| `SmokingStatus` | Ordinal | Never / Former / Current |
| `AlcoholConsumption` | Ordinal | None / Light / Moderate / Heavy |
| `FamilyHistory` | Binary | Yes / No |
| `ChestPain` | Binary | Yes / No |
| `SleepHours` | Numeric | Average sleep hours per night |
| `Cholesterol` | Numeric | Total cholesterol (mg/dL) |
| `CholesterolHDL` | Numeric | HDL (good) cholesterol |
| `CholesterolLDL` | Numeric | LDL (bad) cholesterol |
| `Diabetic` | **Target** | 1 = Diabetic, 0 = Non-Diabetic |

**60 patients** | **30 diabetic, 30 healthy** | **0 missing values**

---

## 🧪 What the Code Does

### Section-by-Section Breakdown

**1. Data Loading & Inspection** — shape, dtypes, class balance

**2. Clinical Descriptive Stats** — mean values grouped by diabetic status

**3. Boxplot Visualizations** — 8 clinical metrics compared across groups

**4. Glucose & HbA1c Histograms** — with WHO clinical thresholds overlaid

**5. Risk Factor Analysis** — stacked bar charts for all categorical variables

**6. Correlation Heatmap** — relationships between all numerical features

**7. Scatter Plots** — BMI vs Glucose and Age vs Glucose, colored by diagnosis

**8. Statistical Significance Tests** — independent t-tests for all key markers

**9. Preprocessing** — label encoding, ordinal encoding, feature engineering

**10. Feature Engineering** — Glucose/BMI ratio, Cholesterol ratio, risk flags

**11. Model Training** — 4 classifiers with stratified cross-validation

**12. Confusion Matrices** — all 4 models side by side

**13. ROC Curves** — with AUC scores

**14. Precision-Recall Curves** — critical for medical screening context

**15. Feature Importances** — Gradient Boosting top predictors

**16. Radar Chart** — normalized risk profile: Diabetic vs Healthy average patient

**17. Clinical Summary Report** — findings and best model metrics

---

## 🤖 Models Used

| Model | Description |
|---|---|
| Logistic Regression | Interpretable baseline classifier |
| Random Forest | Ensemble of decision trees |
| Gradient Boosting | Sequential boosted ensemble |
| SVM (RBF Kernel) | Support Vector Machine |

---

## 📈 Output Plots

| File | Description |
|---|---|
| `H01_clinical_boxplots.png` | 8 clinical metrics by diabetic status |
| `H02_glucose_hba1c.png` | Glucose & HbA1c distributions with thresholds |
| `H03_risk_factors.png` | Categorical risk factor analysis |
| `H04_correlation_heatmap.png` | Feature correlation matrix |
| `H05_bmi_age_scatter.png` | BMI & Age vs Glucose scatter |
| `H06_confusion_matrices.png` | All 4 model confusion matrices |
| `H07_roc_curves.png` | ROC curves with AUC |
| `H08_precision_recall.png` | Precision-Recall curves |
| `H09_feature_importance.png` | Gradient Boosting feature importances |
| `H10_radar_risk_profile.png` | Radar chart: Diabetic vs Healthy patient profile |

---

## 🚀 How to Run

```bash
pip install pandas numpy matplotlib seaborn scikit-learn scipy
cd notebooks/
python 04_Healthcare_Diabetes_Analysis.py
```

---

## 🔬 Key Findings

- **HbA1c ≥ 6.5%** and **Glucose ≥ 126 mg/dL** are the strongest individual predictors
- **Age + BMI interaction** significantly raises risk beyond either factor alone
- **Family history** nearly doubles the likelihood of a diabetic diagnosis
- **Current smokers** show 100% diabetic rate in this dataset
- **Higher physical activity** is strongly protective against diabetes
- **HDL cholesterol** is inversely correlated with diabetic status (good cholesterol is protective)

---

## ⚕️ Clinical Context

> **Note:** This project is for educational purposes only. Real clinical diagnosis requires professional medical evaluation. The HbA1c and Glucose thresholds used (6.5% and 126 mg/dL) follow WHO/ADA guidelines.

---

## 🛠 Tech Stack

`Python 3.8+` · `Pandas` · `NumPy` · `Matplotlib` · `Seaborn` · `Scikit-learn` · `SciPy`

---

## 👤 Author

**Piyush Patane** — Data Science Lab Work, Intermediate Series
